package com.example.clpmonitor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClpmonitorApplicationTests {

	@Test
	void contextLoads() {
	}

}
