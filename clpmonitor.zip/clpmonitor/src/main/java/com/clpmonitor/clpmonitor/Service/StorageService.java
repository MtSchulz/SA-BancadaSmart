package com.clpmonitor.clpmonitor.Service;

public class StorageService {

}
