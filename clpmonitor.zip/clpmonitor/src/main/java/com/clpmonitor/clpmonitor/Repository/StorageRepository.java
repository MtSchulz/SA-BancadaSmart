package com.clpmonitor.clpmonitor.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.clpmonitor.clpmonitor.Model.Storage;

public interface StorageRepository extends JpaRepository<Storage, Long> {

}
